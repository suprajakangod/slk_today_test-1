
public class JenkinsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Jenkins Running from Java program");
	}

}
